#ifndef __TIMER_H
#define __TIMER_H	 
#include "sys.h"  



extern u8 TIM1_FLAG;
extern u8 TIM2_FLAG;
extern u8 TIM3_FLAG;
extern u8 TIM4_FLAG;

extern u16	TIM1_Timing; 
extern u16	TIM2_Timing; 
extern u16	TIM3_Timing; 
extern u16	TIM4_Timing; 


void TIM1_Init(u16 arr,u16 psc);
void TIM2_Init(u16 arr,u16 psc);
void TIM3_Init(u16 arr,u16 psc);
void TIM4_Init(u16 arr,u16 psc);
void TIM5_Init(u16 arr,u16 psc);
void TIM6_Init(u16 arr,u16 psc);
void TIM7_Init(u16 arr,u16 psc);
void TIM8_Init(u16 arr,u16 psc);

#endif
