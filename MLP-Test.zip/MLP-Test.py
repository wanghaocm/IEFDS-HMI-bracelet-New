import torch
import numpy as np
import torch.nn as nn
import torch.optim as optim
from torch.utils.data.dataset import Dataset
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
#import scipy.io as io

# 输入数据的容器，配合DataLoader，完成mini_bacth训练方法，要包含__init__， __len__和__getitem__三个属性
class Dataset(Dataset):
    def __init__(self, train_lines):
        super(Dataset, self).__init__()
        self.lens = len(train_lines)  # 数据量
        self.x_data = []
        self.y_data = []

        # 读取数据部分
        for i in range(self.lens):
            x = train_lines[i].split()[:-1]  # 输入特征
            y = train_lines[i].split()[-1]  # 标签值
            self.x_data.append(x)
            self.y_data.append(y)

    # 数据总数
    def __len__(self):
        return self.lens

    # 根据下标获取其中一条数据
    def __getitem__(self, index):
        # 转换为网络输入形式
        x_data = torch.Tensor(list(map(float, self.x_data[index])))

        y_data_list =int(self.y_data[index])
        y_data_list_finally = []
        y_data_list_finally.append(y_data_list)
        #print(y_data_list_finally)

        #y_data = torch.squeeze(torch.Tensor(list(map(float, self.y_data[index]))) - 1)
        y_data = torch.squeeze(torch.Tensor(y_data_list_finally) - 1)

        return x_data, y_data.long()


# BP神经网络结构，注意BatchNorm的使用
class BPModel(nn.Module):
    def __init__(self):
        super(BPModel, self).__init__()
        # 全连接层节点数
        self.layer1 = nn.Linear(12, 1024)
        self.layer2 = nn.Linear(1024, 512)
        self.layer3 = nn.Linear(512, 256)
        self.layer4 = nn.Linear(256, 5)

        self.dropout1 = nn.Dropout(p=0.15)
        self.dropout2 = nn.Dropout(p=0.15)
        self.BN0 = nn.BatchNorm1d(12, momentum=0.5)
        self.BN1 = nn.BatchNorm1d(1024, momentum=0.5)
        self.BN2 = nn.BatchNorm1d(512, momentum=0.5)
        self.BN3 = nn.BatchNorm1d(256, momentum=0.5)

    def forward(self, x):
        # 可自行添加dropout和BatchNorm1d层
        x = self.BN0(x)
        x = self.BN1(self.layer1(x))
        x = torch.tanh(x)
        x = self.BN2(self.layer2(x))
        x = torch.tanh(x)
        x = self.BN3(self.layer3(x))
        x = torch.tanh(x)
        out = torch.relu(self.layer4(x))
        return out


class BPTrain(object):
    # train_path为训练集文件，val_path为验证集文件
    def __init__(self, train_path, val_path, lr=0.01, epochs=1000, gpu=False):
        self.gpu = gpu  # 是否选用gpu， 默认为False
        self.lr = lr  # 学习率
        self.epochs = epochs  # 迭代次数
        self.loss = []  # 用于绘制loss图像
        self.num_epoch = []

        # 读取训练集数据
        with open(train_path) as f:
            lines = f.readlines()
        train_dataset = Dataset(lines)
        self.gen = DataLoader(train_dataset, shuffle=True, batch_size=50, drop_last=True)

        # 测试集
        with open(val_path) as f:
            lines = f.readlines()
        val_dataset = Dataset(lines)
        self.val_gen = DataLoader(val_dataset,  shuffle=False, batch_size=196, drop_last=True)

    # 权重初始化（好的初始化有利于模型训练）
    def weights_init(self, m):
        if isinstance(m, nn.Conv2d):
            m.weight.data.normal_(0, 0.02)
            m.bias.data.zero_()
        elif isinstance(m, nn.Linear):
            m.weight.data.normal_(0, 0.02)
            m.bias.data.zero_()

    # model_path为模型参数文件
    def train(self, model_path=0):
        # 设备选择
        if not self.gpu:
            device = 'cpu'
        else:
            if torch.cuda.is_available():
                device = torch.device("cuda:0")
            else:
                print(f'gpu is unavailable !!!')
                device = 'cpu'

        # 网络实例化，并设计损失函数、optimizer和lr衰减
        best_val_acc = 0
        model = BPModel()
        if model_path:
            model.load_state_dict(torch.load(model_path))
        else:
            model.apply(self.weights_init)
        model = model.to(device)

        loss_func = nn.CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters(), lr=self.lr)
        lr_scheduler = optim.lr_scheduler.StepLR(optimizer, 100, gamma=0.9)

        for epoch in range(self.epochs):    #迭代500次
            all_loss = 0
            train_rights = 0
            train_falses = 0
            for i, data in enumerate(self.gen, 0):
                inputs, labels = data
                inputs = inputs.to(device)
                labels = labels.to(device)

                model.train()
                optimizer.zero_grad()  # 梯度清零

                output = model(inputs)
                loss = loss_func(output, labels)
                loss.backward()
                optimizer.step()
                lr_scheduler.step()

                output = torch.argmax(output, dim=1)
                train_count_right = output == labels  # mini_batch中正确项
                train_count_false = output != labels  # mini_batch中错误项
                train_rights += sum(train_count_right)
                train_falses += sum(train_count_false)
                all_loss += loss

            self.loss.append(float(all_loss))
            self.num_epoch.append(epoch)

            # 验证集检验频率
            if epoch % 10 == 0:
                print('\n')
                print(f'迭代次数为{epoch}:损失值为{all_loss}')
                print(
                    f'训练集准确率为{train_rights / (train_rights + train_falses)}, 正确数量为{train_rights}， 错误数量为{train_falses}')
                val_rights = 0
                val_falses = 0
                val_acc = 0
                model.eval()  # model.eval() 会关闭BN和dropout
                with torch.no_grad():
                    for j, data in enumerate(self.val_gen, 0):
                        inputs, labels = data
                        inputs = inputs.to(device)
                        labels = labels.to(device)
                        output = model(inputs)
                        saveoutput= output
                        saveoutput = np.array(saveoutput)
                        np.savetxt('ResultSave.txt',saveoutput)
                        output = torch.argmax(output, dim=1)
                        val_count_right = output == labels
                        val_count_false = output != labels
                        val_rights += sum(val_count_right)
                        val_falses += sum(val_count_false)
                        val_acc = val_rights / (val_rights + val_falses)
                    if val_acc > best_val_acc:
                        best_val_acc = val_acc
                        torch.save(model.state_dict(), f'best_{self.gpu}')
                    print(f'测试集准确率为:{val_acc}, 正确数量为{val_rights}, 错误数量为{val_falses}')



    # 绘制Loss值图像
    def draw_loss(self):
        fig = plt.figure(figsize=(10, 6))
        ax1 = fig.add_subplot(1, 1, 1)

        ax1.set_xlabel('epoch')
        ax1.set_ylabel('loss')
        ax1.set_title("Loss picture")
        np.savetxt('loss.txt', self.loss)
        ax1.plot(self.num_epoch, self.loss)

        plt.savefig('Loss_chart.jpg')
        plt.show()


def predict(model_path, pre_path, gpu=False):
    inputs = []
    with open(pre_path) as f:
        lines = f.readlines()
        for i in range(len(lines)):
            x = list(map(float, lines[i].split()))
            inputs.append(x)
    inputs = torch.tensor(inputs)

    if not gpu:
        device = 'cpu'
    else:
        if torch.cuda.is_available():
            device = torch.device("cuda:0")
        else:
            print(f'gpu is unavailable !!!')
            device = 'cpu'

    model = BPModel()
    model.load_state_dict(torch.load(model_path))
    model = model.to(device)
    model.eval()
    inputs = inputs.to(device)
    output = model(inputs)
    output = torch.argmax(output, dim=1)


if __name__ == '__main__':
    # 文件路径
    train_path = r'MLP_Training_Data.txt'    #训练数据组文件路径
    val_path = r'MLP_Testing_Data.txt'       #测试数据组文件路径
    model_path = r'best_False'  # 训练好的权重文件
    pre_path = 'predata.txt'  # 预测数据

    training_BP = BPTrain(train_path, val_path)
    training_BP.train()
    training_BP.draw_loss()

    #predict(model_path, pre_path, gpu=False)